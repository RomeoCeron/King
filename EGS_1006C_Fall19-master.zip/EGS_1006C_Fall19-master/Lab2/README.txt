Lab2
-------

Monday - 8:30 Meeting
Tuesday - 11:30 Meeting
