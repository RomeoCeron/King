
void encoder_init(void);
int get_left_motor_count();
int get_right_motor_count();
